# Boss Menu -> CD Garages bridge

Boss Menu-created garages are exposed through ox_target and use CD Garages for the actual UI/spawning. If the location is not already a native CD Garage, the bridge creates/uses a CD property garage for the current employee and synchronises their currently stored personal vehicles to that garage before opening the CD UI. This makes the vehicles selectable/spawnable rather than merely visible in the generic CD vehicle list.

Existing banking, inventory, applications and Boss Menu garage CRUD are unchanged.
