# Brah Bossmenu — QBox + Renewed-Banking build

This build is configured specifically for:

- QBox (`qbx_core`)
- Renewed-Banking
- oxmysql
- ox_lib
- ox_target
- ox_inventory
- Illenium Appearance

## Important banking note

Renewed-Banking is the authoritative source for society/gang balances. The legacy `bossmenu_accounts.balance` column is retained only for backwards-compatible records and is no longer used as the live balance when Renewed-Banking is active.

Renewed-Banking documents these server exports:

- `getAccountMoney(account)`
- `addAccountMoney(account, amount)`
- `removeAccountMoney(account, amount)`
- `handleTransaction(...)`

For Renewed-Banking's own banking UI, QBox job/gang grades that should access society funds should have `bankAuth = true` in the corresponding QBox job/gang definition.

## Installation

1. Replace the old `brah_bossmenu` folder with this folder.
2. Ensure `qbx_core`, `Renewed-Banking`, `ox_lib`, `ox_target`, and `oxmysql` start before `brah_bossmenu`.
3. Keep the existing Brah Bossmenu SQL installed. No destructive migration is performed by this build.
4. Restart the resource/server.

## What was changed

- QBox is the configured framework.
- Renewed-Banking is the authoritative society/gang bank.
- Removed the broken Renewed-Banking uppercase export fallback.
- Fixed society-account initialisation to wait for Renewed-Banking's cached QBox job account instead of repeatedly attempting duplicate account creation.
- The Command Deck now resolves the live Renewed-Banking account before reading the Medical/department budget, so existing Renewed-Banking funds are reflected.
- Uses Renewed-Banking `GetJobAccount` when available and only attempts account creation after the normal cache-loading window.
- Keeps Renewed-Banking as the single source of truth for society balances and transactions.
- Deposits refund player cash if the society-bank deposit fails.
- Withdrawals refund the society account if cash delivery fails.
- Renewed-Banking transaction history is populated for supported money movements.
- Payroll now pays employees through QBox instead of only deducting society funds.
- QBox grade `payment` values are used as framework salary defaults.
- Salary overrides still take precedence.
- Admin add/remove funds use the same authoritative banking layer.
- Tax payments use the same authoritative banking layer.
- Gang/territory/contract/racket money uses the same authoritative banking layer.
- NUI close always releases focus and clears the session token.
- QBox group-update events refresh the client player data.
- Debug logging is disabled by default.


Payroll fix: automatic payroll is enabled by default and runs every Config.Payroll.autoIntervalMinutes (default 60). Payroll uses each employee grade payment/salary override, removes the exact paid amount from the Renewed-Banking society account, and pays the employee through qbx_core AddMoney (online or offline citizenid). Failed employee payments are rolled back to the society account.
