-- Boss Menu -> CD Garages bridge
-- Creates an ox_target interaction at every garage created in the Boss Menu.
-- The actual vehicle UI is handled by cd_garage.

local syncedGarages = {}
local targetZones = {}
local bridgeStarted = false

local function notify(message, type)
    if lib and lib.notify then
        lib.notify({ description = message, type = type or 'inform' })
    else
        BeginTextCommandThefeedPost('STRING')
        AddTextComponentSubstringPlayerName(message)
        EndTextCommandThefeedPostTicker(false, false)
    end
end

local function getPlayerRole()
    local data = Framework and Framework.GetClientPlayerData and Framework.GetClientPlayerData() or nil
    if not data then return nil, nil end
    if data.job and data.job.name then return 'boss', tostring(data.job.name) end
    if data.gang and data.gang.name then return 'gang', tostring(data.gang.name) end
    return nil, nil
end

local function removeZone(id)
    local zone = targetZones[id]
    if not zone then return end
    if GetResourceState('ox_target') == 'started' and exports.ox_target and exports.ox_target.removeZone then
        pcall(function() exports.ox_target:removeZone(zone) end)
    end
    targetZones[id] = nil
end

local function openCdGarage(garage)
    if GetResourceState('cd_garage') ~= 'started' then
        notify('CD Garages is not started.', 'error')
        return
    end

    local c = garage.coords or {}
    local x, y, z = tonumber(c.x), tonumber(c.y), tonumber(c.z)
    if not x or not y or not z then
        notify('This garage has invalid coordinates.', 'error')
        return
    end

    local heading = tonumber(c.w or c.h or c.heading) or GetEntityHeading(PlayerPedId())

    -- Use CD Garages' documented PropertyGarage:Open integration directly.
    -- CD Garages handles finding/creating the nearby property garage, loading
    -- the player's stored vehicles, and spawning/storing them.
    -- A normal mutable table is used instead of vector4 because some CD Garage
    -- versions modify the supplied coordinate table internally.
    TriggerEvent('cd_garage:PropertyGarage:Open', {
        x = x,
        y = y,
        z = z,
        h = heading
    })
end

local function storeCdVehicle()
    if GetResourceState('cd_garage') ~= 'started' then
        notify('CD Garages is not started.', 'error')
        return
    end
    TriggerEvent('cd_garage:PropertyGarage:StoreVehicle')
end

local function addGarageZone(garage)
    if type(garage) ~= 'table' then return end
    local id = tonumber(garage.id)
    local c = garage.coords or {}
    if not id or not c.x or not c.y or not c.z then return end
    if GetResourceState('ox_target') ~= 'started' then return end

    removeZone(id)

    local roleType, roleName = getPlayerRole()
    if roleType ~= tostring(garage.org_type or 'boss') or roleName ~= tostring(garage.org_name or '') then
        return
    end

    local radius = 2.5
    local zone = exports.ox_target:addSphereZone({
        coords = vector3(tonumber(c.x), tonumber(c.y), tonumber(c.z)),
        radius = radius,
        debug = false,
        options = {
            {
                name = ('brah_bossmenu_garage_open_%s'):format(id),
                icon = 'fa-solid fa-car',
                label = ('Open %s'):format(tostring(garage.name or 'Garage')),
                distance = 2.5,
                canInteract = function()
                    local rt, rn = getPlayerRole()
                    return rt == tostring(garage.org_type or 'boss') and rn == tostring(garage.org_name or '')
                end,
                onSelect = function()
                    openCdGarage(garage)
                end
            },
            {
                name = ('brah_bossmenu_garage_store_%s'):format(id),
                icon = 'fa-solid fa-square-parking',
                label = 'Store Vehicle',
                distance = 2.5,
                canInteract = function()
                    local rt, rn = getPlayerRole()
                    return rt == tostring(garage.org_type or 'boss') and rn == tostring(garage.org_name or '') and IsPedInAnyVehicle(PlayerPedId(), false)
                end,
                onSelect = function()
                    storeCdVehicle()
                end
            }
        }
    })
    targetZones[id] = zone
end

local function rebuildZones()
    for id in pairs(targetZones) do
        removeZone(id)
    end
    for _, garage in pairs(syncedGarages) do
        addGarageZone(garage)
    end
end

RegisterNetEvent('qb-management:client:syncOrgGarages', function(garages)
    syncedGarages = type(garages) == 'table' and garages or {}
    rebuildZones()
end)

RegisterNetEvent('QBCore:Client:OnJobUpdate', function()
    Wait(250)
    TriggerServerEvent('qb-management:server:requestGarageSync')
end)
RegisterNetEvent('QBCore:Client:OnGangUpdate', function()
    Wait(250)
    TriggerServerEvent('qb-management:server:requestGarageSync')
end)
RegisterNetEvent('qbx_core:client:onGroupUpdate', function()
    Wait(250)
    TriggerServerEvent('qb-management:server:requestGarageSync')
end)

CreateThread(function()
    while GetResourceState('ox_target') ~= 'started' do Wait(500) end
    bridgeStarted = true
    Wait(1500)
    TriggerServerEvent('qb-management:server:requestGarageSync')
end)

RegisterNetEvent('brah_bossmenu:client:garageBridgeNotify', function(message, kind)
    notify(message, kind or 'inform')
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for id in pairs(targetZones) do
        removeZone(id)
    end
end)
