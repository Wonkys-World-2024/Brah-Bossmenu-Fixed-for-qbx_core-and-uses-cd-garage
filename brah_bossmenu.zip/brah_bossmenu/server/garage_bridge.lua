-- Boss Menu garage synchronisation bridge.
-- Kept in its own server script so the large server/main.lua does not hit
-- Lua's 200-local limit.

local function loadGaragesForOrg(orgType, orgName)
    local rows = MySQL.query.await([[SELECT id, org_type, org_name, name, coords, options_json
        FROM bossmenu_org_garages
        WHERE org_type = ? AND org_name = ?
        ORDER BY id ASC]], { tostring(orgType or ''), tostring(orgName or '') }) or {}

    for i = 1, #rows do
        local c = rows[i].coords
        local o = rows[i].options_json
        if type(c) == 'string' then
            local ok, value = pcall(json.decode, c)
            rows[i].coords = ok and value or {}
        elseif type(c) ~= 'table' then
            rows[i].coords = {}
        end
        if type(o) == 'string' then
            local ok, value = pcall(json.decode, o)
            rows[i].options_json = ok and value or {}
        elseif type(o) ~= 'table' then
            rows[i].options_json = {}
        end
    end
    return rows
end

local function syncPlayer(src)
    -- The client filters the returned list against the player's current job/gang.
    -- Sending the small garage list here also avoids depending on a particular
    -- Qbox GetPlayersData export, which differs between qbx_core releases.
    local rows = MySQL.query.await([[SELECT id, org_type, org_name, name, coords, options_json
        FROM bossmenu_org_garages ORDER BY id ASC]]) or {}

    for i = 1, #rows do
        if type(rows[i].coords) == 'string' then
            local ok, value = pcall(json.decode, rows[i].coords)
            rows[i].coords = ok and value or {}
        end
        if type(rows[i].options_json) == 'string' then
            local ok, value = pcall(json.decode, rows[i].options_json)
            rows[i].options_json = ok and value or {}
        end
    end

    TriggerClientEvent('qb-management:client:syncOrgGarages', src, rows)
end

RegisterNetEvent('qb-management:server:requestGarageSync', function()
    syncPlayer(source)
end)

RegisterNetEvent('brah_bossmenu:server:garageChanged', function(orgType, orgName)
    -- The requesting boss gets an immediate refresh. Other players refresh on
    -- their normal job/gang update or resource restart, so no large broadcast
    -- loop is required here.
    local src = source
    if src and src > 0 then
        syncPlayer(src)
    end
end)

AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    CreateThread(function()
        Wait(1500)
        for _, playerSrc in ipairs(GetPlayers()) do
            syncPlayer(tonumber(playerSrc))
        end
    end)
end)

