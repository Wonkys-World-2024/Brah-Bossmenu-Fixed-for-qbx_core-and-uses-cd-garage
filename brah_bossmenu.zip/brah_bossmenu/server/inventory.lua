InventoryModule = InventoryModule or {}
InventoryModule._stashReady = InventoryModule._stashReady or {}
InventoryModule._warned = InventoryModule._warned or {}

function InventoryModule.GetIntegration()
    local integrations = Config.Integrations or {}
    local mode = tostring(integrations.inventory or 'auto')
    if mode ~= 'auto' then
        return mode
    end
    if GetResourceState('ox_inventory') == 'started' then return 'ox_inventory' end
    if GetResourceState('qb-inventory') == 'started' then return 'qb-inventory' end
    if GetResourceState('ps-inventory') == 'started' then return 'ps-inventory' end
    if GetResourceState('lj-inventory') == 'started' then return 'lj-inventory' end
    if GetResourceState('qs-inventory') == 'started' then return 'qs-inventory' end
    return 'none'
end

local function invCleanText(value, maxLen)
    local out = tostring(value or '')
    out = out:gsub('[\r\n\t]', ' ')
    out = out:gsub('%s%s+', ' ')
    out = out:gsub('^%s+', ''):gsub('%s+$', '')
    if maxLen and #out > maxLen then
        out = out:sub(1, maxLen)
    end
    return out
end

local function invNum(value, min, max)
    local n = tonumber(value)
    if not n then return nil end
    if min and n < min then return nil end
    if max and n > max then return nil end
    return n
end

local function invWarnOnce(key, message)
    if InventoryModule._warned[key] then return end
    InventoryModule._warned[key] = true
    print(('[%s] inventory integration warning: %s'):format(GetCurrentResourceName(), message))
end

local function invCall(resource, fn, ...)
    local args = { ... }
    local ok, result = pcall(function()
        return exports[resource][fn](table.unpack(args))
    end)
    if not ok then return nil end
    return result
end

local function stashId(orgType, orgName)
    return ('bm:%s:%s'):format(tostring(orgType or 'boss'), tostring(orgName or 'unknown'))
end

local function ensureOxStash(orgType, orgName)
    local id = stashId(orgType, orgName)
    if InventoryModule._stashReady[id] then
        return id
    end
    local label = ('%s %s Stash'):format(orgType == 'gang' and 'Gang' or 'Organization', tostring(orgName))
    pcall(function()
        exports.ox_inventory:RegisterStash(id, label, 250, 1000000, false)
    end)
    InventoryModule._stashReady[id] = true
    return id
end

local function invAudit(orgType, orgName, action, actor, target, metadata)
    if AuditModule and AuditModule.Write then
        AuditModule.Write(orgType, orgName, ('%s:%s'):format(orgType, action), actor, target, metadata or {})
        return
    end
    MySQL.insert.await([[INSERT INTO bossmenu_audit (job, action, actor_identifier, target_identifier, payload)
        VALUES (?, ?, ?, ?, ?)]], {
        orgName,
        ('%s:%s'):format(orgType, action),
        actor,
        target,
        metadata and json.encode(metadata) or nil
    })
end

function InventoryModule.IsEnabled()
    return Config.Modules and Config.Modules.BusinessInventory == true
end

local function moveViaOx(orgType, orgName, actorSource, item, amount, metadata, direction)
    local src = invNum(actorSource, 1)
    if not src then return false, 'Invalid source' end
    amount = tonumber(amount)
    if not amount or amount < 1 then return false, 'Invalid amount' end
    amount = math.floor(amount)

    local stash = ensureOxStash(orgType, orgName)

    -- Make absolutely sure the stash exists and is loaded before attempting
    -- server-side item movement. ox_inventory requires a registered/loaded
    -- stash for AddItem/RemoveItem operations.
    local stashInventory = nil
    local okGet, getResult = pcall(function()
        return exports.ox_inventory:GetInventory(stash)
    end)
    if okGet then stashInventory = getResult end

    if not stashInventory then
        -- RegisterStash is idempotent in normal use; if it is already
        -- registered, GetInventory above should have returned it.
        local okRegister, registerResult = pcall(function()
            return exports.ox_inventory:RegisterStash(
                stash,
                ('%s %s Stash'):format(orgType == 'gang' and 'Gang' or 'Organization', tostring(orgName)),
                250,
                1000000,
                false
            )
        end)
        if not okRegister then
            return false, 'Could not register the ox_inventory stash'
        end
        pcall(function()
            stashInventory = exports.ox_inventory:GetInventory(stash)
        end)
        if not stashInventory then
            return false, 'Could not load the ox_inventory stash'
        end
    end

    local function oxExport(fn, ...)
        local args = { ... }
        local ok, success, response = pcall(function()
            if fn == 'AddItem' then
                return exports.ox_inventory:AddItem(table.unpack(args))
            elseif fn == 'RemoveItem' then
                return exports.ox_inventory:RemoveItem(table.unpack(args))
            elseif fn == 'Search' then
                return exports.ox_inventory:Search(table.unpack(args))
            elseif fn == 'GetInventory' then
                return exports.ox_inventory:GetInventory(table.unpack(args))
            end
            return exports.ox_inventory[fn](table.unpack(args))
        end)
        if not ok then
            return false, 'ox_inventory export error'
        end
        -- ox_inventory can return true, reason or true, response depending on
        -- the operation/version. Preserve the actual response for the UI.
        if success == true then return true, response end
        if success then return true, response or success end
        return false, response or 'ox_inventory rejected the item operation'
    end

    if direction == 'deposit' then
        -- Check the player's actual item count first so the UI gets the real
        -- ox_inventory failure instead of a generic amount error.
        -- Verify the item exists in ox_inventory's item registry. This avoids
        -- misleading 'invalid item' responses when the NUI sends a label or
        -- whitespace instead of the real item name.
        local itemDef
        local okItem, itemResult = pcall(function()
            return exports.ox_inventory:Items(item)
        end)
        if okItem then itemDef = itemResult end
        if not itemDef then
            return false, ('Invalid item: %s is not registered in ox_inventory'):format(item)
        end

        local playerCount = 0
        local okSearch, searchResult = pcall(function()
            return exports.ox_inventory:Search(src, 'count', item, metadata)
        end)
        if okSearch then playerCount = tonumber(searchResult) or 0 end
        if playerCount < amount then
            return false, ('Not enough %s (you have %d)'):format(item, playerCount)
        end

        local removed, removeResponse = oxExport('RemoveItem', src, item, amount, metadata)
        if not removed then
            return false, removeResponse or 'Could not remove item from your inventory'
        end

        local added, addResponse = oxExport('AddItem', stash, item, amount, metadata)
        if not added then
            -- Roll the item back to the player if the stash refuses it.
            oxExport('AddItem', src, item, amount, metadata)
            return false, addResponse or 'Could not add item to the boss stash'
        end

        return true
    end

    local removed, removeResponse = oxExport('RemoveItem', stash, item, amount, metadata)
    if not removed then
        return false, removeResponse or 'Could not remove item from the boss stash'
    end

    local added, addResponse = oxExport('AddItem', src, item, amount, metadata)
    if not added then
        -- Roll the item back to the stash if the player cannot carry it.
        oxExport('AddItem', stash, item, amount, metadata)
        return false, addResponse or 'Could not add item to your inventory'
    end

    return true
end

local function moveViaQb(orgType, orgName, actorSource, item, amount, metadata, direction)
    local src = invNum(actorSource, 1)
    if not src then return false, 'Invalid source' end
    local stash = stashId(orgType, orgName)
    local reason = GetCurrentResourceName()

    if direction == 'deposit' then
        local okRemove = invCall('qb-inventory', 'RemoveItem', src, item, amount, false, nil, reason)
        if okRemove ~= true then
            return false, 'Insufficient item amount'
        end
        local okAdd = invCall('qb-inventory', 'AddToStash', stash, item, amount, false, metadata or {}, reason)
        if okAdd ~= true then
            invCall('qb-inventory', 'AddItem', src, item, amount, false, metadata or {}, reason)
            return false, 'Stash add failed'
        end
        return true
    end

    local okTake = invCall('qb-inventory', 'RemoveFromStash', stash, item, amount, false, reason)
    if okTake ~= true then
        return false, 'Insufficient item amount'
    end
    local okGive = invCall('qb-inventory', 'AddItem', src, item, amount, false, metadata or {}, reason)
    if okGive ~= true then
        invCall('qb-inventory', 'AddToStash', stash, item, amount, false, metadata or {}, reason)
        return false, 'Cannot carry item'
    end
    return true
end

local function moveViaQbFamily(resourceName, orgType, orgName, actorSource, item, amount, metadata, direction)
    local src = invNum(actorSource, 1)
    if not src then return false, 'Invalid source' end
    local stash = stashId(orgType, orgName)
    local reason = GetCurrentResourceName()

    if direction == 'deposit' then
        local okRemove = invCall(resourceName, 'RemoveItem', src, item, amount, false, nil, reason)
        if okRemove ~= true then
            return false, 'Insufficient item amount'
        end
        local okAdd = invCall(resourceName, 'AddToStash', stash, item, amount, false, metadata or {}, reason)
        if okAdd ~= true then
            invCall(resourceName, 'AddItem', src, item, amount, false, metadata or {}, reason)
            return false, 'Stash add failed'
        end
        return true
    end

    local okTake = invCall(resourceName, 'RemoveFromStash', stash, item, amount, false, reason)
    if okTake ~= true then
        return false, 'Insufficient item amount'
    end
    local okGive = invCall(resourceName, 'AddItem', src, item, amount, false, metadata or {}, reason)
    if okGive ~= true then
        invCall(resourceName, 'AddToStash', stash, item, amount, false, metadata or {}, reason)
        return false, 'Cannot carry item'
    end
    return true
end

local function moveViaQs(orgType, orgName, actorSource, item, amount, metadata, direction)
    local src = invNum(actorSource, 1)
    if not src then return false, 'Invalid source' end
    local stash = stashId(orgType, orgName)

    if direction == 'deposit' then
        local removed = invCall('qs-inventory', 'RemoveItem', src, item, amount)
        if removed ~= true then
            return false, 'Insufficient item amount'
        end
        local stored = invCall('qs-inventory', 'AddItemToStash', stash, item, amount, metadata or {})
        if stored ~= true then
            invCall('qs-inventory', 'AddItem', src, item, amount, metadata or {})
            return false, 'Stash add failed'
        end
        return true
    end

    local pulled = invCall('qs-inventory', 'RemoveItemFromStash', stash, item, amount)
    if pulled ~= true then
        return false, 'Insufficient item amount'
    end
    local given = invCall('qs-inventory', 'AddItem', src, item, amount, metadata or {})
    if given ~= true then
        invCall('qs-inventory', 'AddItemToStash', stash, item, amount, metadata or {})
        return false, 'Cannot carry item'
    end
    return true
end


function InventoryModule.ModifyItem(orgType, orgName, itemName, amountDelta, actor, actionLabel, metadata, actorSource)
    local item = invCleanText(itemName, 80)
    local delta = tonumber(amountDelta) or 0
    if item == '' or delta == 0 then
        return false, 'Invalid item or amount'
    end

    local backend = InventoryModule.GetIntegration()
    local direction = delta > 0 and 'deposit' or 'withdraw'
    local absDelta = math.abs(delta)
    local integrationOK = false
    local integrationErr = nil

    if backend == 'ox_inventory' then
        integrationOK, integrationErr = moveViaOx(orgType, orgName, actorSource, item, absDelta, metadata, direction)
        if integrationOK then
            -- ox_inventory is authoritative for the actual stash contents, but
            -- bossmenu still maintains its own audit/history feed for the UI.
            -- Previously we returned here before writing the history row, which
            -- made successful deposits appear to have no history at all.
            MySQL.insert.await([[INSERT INTO bossmenu_org_inventory_logs (org_type, org_name, action, item_name, amount, actor_identifier, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?)]], {
                orgType, orgName, invCleanText(actionLabel, 24), item, absDelta, actor, metadata and json.encode(metadata) or nil
            })
            invAudit(orgType, orgName, 'inventory_' .. invCleanText(actionLabel, 24), actor, nil, {
                item = item,
                delta = delta,
                backend = backend
            })
            return true
        end
    elseif backend == 'qb-inventory' then
        integrationOK, integrationErr = moveViaQb(orgType, orgName, actorSource, item, absDelta, metadata, direction)
    elseif backend == 'ps-inventory' then
        integrationOK, integrationErr = moveViaQbFamily('ps-inventory', orgType, orgName, actorSource, item, absDelta, metadata, direction)
    elseif backend == 'lj-inventory' then
        integrationOK, integrationErr = moveViaQbFamily('lj-inventory', orgType, orgName, actorSource, item, absDelta, metadata, direction)
    elseif backend == 'qs-inventory' then
        integrationOK, integrationErr = moveViaQs(orgType, orgName, actorSource, item, absDelta, metadata, direction)
    elseif backend ~= 'none' then
        invWarnOnce(backend, ('unknown backend "%s", using db fallback'):format(backend))
    end

    if backend ~= 'none' and backend ~= 'auto' then
        if integrationOK ~= true and integrationErr then
            return false, integrationErr
        end
        if integrationOK ~= true then
            invWarnOnce(backend .. ':fallback', ('backend "%s" action unsupported, using db fallback'):format(backend))
        end
    end

    MySQL.insert.await([[INSERT INTO bossmenu_org_inventory (org_type, org_name, item_name, amount, metadata)
        VALUES (?, ?, ?, 0, ?)
        ON DUPLICATE KEY UPDATE item_name = VALUES(item_name)]], {
        orgType, orgName, item, json.encode(metadata or {})
    })

    local affected = 0
    if delta > 0 then
        affected = MySQL.update.await([[UPDATE bossmenu_org_inventory
            SET amount = amount + ?, metadata = COALESCE(?, metadata), updated_at = NOW()
            WHERE org_type = ? AND org_name = ? AND item_name = ?]], {
            delta, metadata and json.encode(metadata) or nil, orgType, orgName, item
        })
    else
        affected = MySQL.update.await([[UPDATE bossmenu_org_inventory
            SET amount = amount + ?, metadata = COALESCE(?, metadata), updated_at = NOW()
            WHERE org_type = ? AND org_name = ? AND item_name = ? AND amount >= ?]], {
            delta, metadata and json.encode(metadata) or nil, orgType, orgName, item, math.abs(delta)
        })
    end

    if (affected or 0) < 1 then
        return false, 'Insufficient item amount'
    end

    MySQL.insert.await([[INSERT INTO bossmenu_org_inventory_logs (org_type, org_name, action, item_name, amount, actor_identifier, metadata)
        VALUES (?, ?, ?, ?, ?, ?, ?)]], {
        orgType, orgName, invCleanText(actionLabel, 24), item, absDelta, actor, metadata and json.encode(metadata) or nil
    })
    invAudit(orgType, orgName, 'inventory_' .. invCleanText(actionLabel, 24), actor, nil, {
        item = item,
        delta = delta,
        backend = backend
    })
    TriggerEvent('qb-management:server:hook', 'inventory_changed', {
        orgType = orgType,
        orgName = orgName,
        action = actionLabel,
        item = item,
        delta = delta,
        actor = actor
    })
    return true
end

function InventoryModule.GetItems(orgType, orgName)
    local backend = InventoryModule.GetIntegration()
    if backend == 'ox_inventory' then
        local stash = ensureOxStash(orgType, orgName)
        local out = {}
        local byItem = {}

        local function addRows(rows)
            if type(rows) ~= 'table' then return 0 end
            if type(rows.items) == 'table' then rows = rows.items end
            if type(rows.inventory) == 'table' then rows = rows.inventory end

            local found = 0
            for _, row in pairs(rows) do
                if type(row) == 'table' then
                    local okRow, name, count, metadata = pcall(function()
                        return row.name or row.item or row.item_name,
                            tonumber(row.count or row.amount or row.quantity) or 0,
                            row.metadata
                    end)
                    if okRow and name and name ~= '' and count > 0 then
                        local key = tostring(name)
                        local entry = byItem[key]
                        if not entry then
                            entry = {
                                item_name = key,
                                amount = 0,
                                metadata = metadata or {},
                                updated_at = nil
                            }
                            byItem[key] = entry
                            out[#out + 1] = entry
                        end
                        entry.amount = entry.amount + count
                        if metadata then entry.metadata = metadata end
                        found = found + 1
                    end
                end
            end
            return found
        end

        -- ox_inventory's GetInventoryItems export returns the current in-memory
        -- slot table. A successful empty table is IMPORTANT: it means the stash
        -- really is empty and must not fall back to old database data.
        local rawItems
        local rawOk = false
        local okItems, itemsResult = pcall(function()
            return exports.ox_inventory:GetInventoryItems(stash, false)
        end)
        if okItems and type(itemsResult) == 'table' then
            rawItems = itemsResult
            rawOk = true
            addRows(rawItems)
        end

        -- Some ox_inventory builds expose the same live slots through the
        -- inventory object. Only use this to supplement the live result when
        -- GetInventoryItems itself was unavailable.
        if not rawOk then
            local okInv, inv = pcall(function()
                return exports.ox_inventory:GetInventory(stash, false)
            end)
            if okInv and type(inv) == 'table' then
                if type(inv.items) == 'table' then
                    rawOk = true
                    addRows(inv.items)
                elseif type(inv.inventory) == 'table' then
                    rawOk = true
                    addRows(inv.inventory)
                end
            end
        end

        -- ONLY use persisted data if both live inventory exports failed. Never
        -- use the database merely because the live stash is empty, otherwise a
        -- legitimately emptied stash gets repopulated in the BossMenu display
        -- with stale quantities from ox_inventory's last database save.
        if not rawOk then
            local okDb, data = pcall(function()
                return MySQL.scalar.await(
                    'SELECT data FROM ox_inventory WHERE owner = ? AND name = ? LIMIT 1',
                    { '', stash }
                )
            end)
            if okDb and data then
                if type(data) == 'string' then
                    local decodedOk, decoded = pcall(json.decode, data)
                    if decodedOk then data = decoded end
                end
                addRows(data)
            end
        end

        table.sort(out, function(a, b)
            return tostring(a.item_name) < tostring(b.item_name)
        end)
        return out
    end

    local rows = MySQL.query.await([[SELECT item_name, amount, metadata, updated_at
        FROM bossmenu_org_inventory
        WHERE org_type = ? AND org_name = ?
        ORDER BY item_name ASC]], { orgType, orgName }) or {}
    for i = 1, #rows do
        rows[i].amount = tonumber(rows[i].amount) or 0
        if rows[i].metadata then
            local ok, decoded = pcall(json.decode, rows[i].metadata)
            if ok and decoded then rows[i].metadata = decoded end
        end
    end
    return rows
end

function InventoryModule.GetLogs(orgType, orgName, limit)
    local nLimit = tonumber(limit) or 100
    if nLimit < 1 then nLimit = 1 end
    if nLimit > 500 then nLimit = 500 end
    local rows = MySQL.query.await([[SELECT id, action, item_name, amount, actor_identifier, target_identifier, metadata, created_at
        FROM bossmenu_org_inventory_logs
        WHERE org_type = ? AND org_name = ?
        ORDER BY id DESC
        LIMIT ?]], { orgType, orgName, nLimit }) or {}
    for i = 1, #rows do
        rows[i].metadata = (type(rows[i].metadata) == 'string' and json.decode(rows[i].metadata)) or rows[i].metadata or {}
    end
    return rows
end
