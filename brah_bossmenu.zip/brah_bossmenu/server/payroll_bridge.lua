-- Boss Menu payroll framework bridge.
-- IMPORTANT: this file must NOT modify Qbox job grades at runtime.
-- Doing so can invalidate the player's live isboss/bankAuth state and make
-- the Boss Menu target/command disappear.

local FrameworkSalaryCache = {}

function FinanceModule.GetFrameworkSalary(orgName, grade)
    local row = FrameworkSalaryCache[tostring(orgName or '')]
    local amount = row and row[tonumber(grade) or 0]
    if amount ~= nil then
        return { salary_type = 'framework', salary_amount = tonumber(amount) or 0 }
    end
    return nil
end

local function cacheQboxFrameworkSalaries()
    if Framework.GetName() ~= 'qbox' then return end
    local payroll = Config.Payroll or {}
    if payroll.cacheFrameworkSalaries ~= true then return end
    if type(payroll.frameworkPaycheckJobs) ~= 'table' then return end

    local jobs = exports.qbx_core:GetJobs() or {}
    for jobName, enabled in pairs(payroll.frameworkPaycheckJobs) do
        if enabled == true then
            local job = jobs[jobName] or exports.qbx_core:GetJob(jobName)
            if job and type(job.grades) == 'table' then
                FrameworkSalaryCache[jobName] = FrameworkSalaryCache[jobName] or {}
                for grade, gradeData in pairs(job.grades) do
                    local level = tonumber(grade)
                    if level and type(gradeData) == 'table' then
                        FrameworkSalaryCache[jobName][level] = tonumber(gradeData.payment) or 0
                    end
                end
            end
        end
    end
end

FinanceModule.PayEmployee = function(identifier, amount, reason)
    amount = tonumber(amount) or 0
    if amount <= 0 or not identifier then return false end
    if Framework.GetName() == 'qbox' then
        return exports.qbx_core:AddMoney(identifier, 'bank', amount, reason or 'payroll') == true
    end
    return false
end

CreateThread(function()
    Wait(1500)
    cacheQboxFrameworkSalaries()
end)
